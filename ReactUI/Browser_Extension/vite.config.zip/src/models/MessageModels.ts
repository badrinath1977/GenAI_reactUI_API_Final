export interface Message {
  type: "user" | "bot";
  text: string;
}
